//
//  DetailView.swift
//  GifSwiftUI
//
//  Created by Praveen Verma on 16/04/25.
//

import SwiftUI

struct DetailView: View {
    
    let product: Product
    
    
    
    @State private var isLiked = false
    @State private var navigateToCart = false
    
    var body: some View {
        
        VStack(spacing: 0) {
            // Custom header
            HStack {
                Text("Cart")
                    .font(.title2)
                    .bold()
                Spacer()
                HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/,spacing: 10) {
                    
                    Button {
                        isLiked.toggle()
                        let cartItem = CartItem(
                            id: product.id,
                            title: product.title,
                            price: product.price,
                            imageName: product.image
                        )
                        saveToUserDefaults(cartItem: cartItem)
                    } label: {
                        Image(systemName: isLiked ? "heart.fill" : "heart")
                            .foregroundColor(isLiked ? .red : .black)
                            .font(.system(size: 24))
                        
                    }
                    
                    
                    Button {
                        shareProduct()
                        
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.black)
                        
                    }
                    
                    
                }
                .font(.title2)
            }
            .padding()
            
            TabView {
                
                
                AsyncImage(url: URL(string: product.image)) { image in
                    image
                        .resizable()
                        .scaledToFit()
                } placeholder: {
                    ProgressView()
                }
                .padding()
                
            }
            .frame(height: 240)
            .tabViewStyle(PageTabViewStyle())
            
            VStack(alignment: .leading, spacing: 12) {
                Text(product.title)
                    .font(.title3)
                    .bold()
                
                HStack {
                    Label("4.8", systemImage: "star.fill")
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    
                    Text("117 reviews")
                        .font(.caption)
                        .foregroundColor(.gray)
                    
                    Label("94%", systemImage: "hand.thumbsup")
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    
                    Label("8", systemImage: "message")
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                }
                
                HStack {
                    Text("£\(String(format: "%.2f", product.price))")
                        .font(.title2)
                        .bold()
                    Spacer()
                    Text("from £14 per month")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
                
                Text("The Nintendo Switch gaming console is a compact device that can be taken everywhere. This portable super device is also equipped with 2 gamepads.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .lineLimit(4)
                
                Button("Read more") {}
                    .font(.caption)
                    .foregroundColor(.blue)
                
                Spacer()
                
                
                VStack(spacing: 8) {
                                   // NavigationLink triggered by state
//                                   NavigationLink(destination: CartView(cartItems: loadCartItems()), isActive: $navigateToCart) {
//                                       EmptyView()
//                                   }
                    
                    NavigationLink(destination: CartView(), isActive: $navigateToCart) {
                        EmptyView()
                    }
                                   
                                   Button(action: {
                                       let cartItem = CartItem(
                                           id: product.id,
                                           title: product.title,
                                           price: product.price,
                                           imageName: product.image
                                       )
                                       saveToUserDefaults(cartItem: cartItem)
                                       navigateToCart = true
                                   }) {
                                       Text("Add to cart")
                                           .frame(maxWidth: .infinity)
                                           .padding()
                                           .background(Color.green)
                                           .foregroundColor(.white)
                                           .cornerRadius(12)
                                           .font(.headline)
                                   }
                    
                    
                     
                    Text("Delivery on 26 October")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
                .padding()
                
                
                
                
            }
            .padding()
        }
    }
}

#Preview {
    DetailView(product: Product(id: 1, title: "Sample Product", price: 19.99, image: "https://via.placeholder.com/150"))
}



func saveToUserDefaults(cartItem: CartItem) {
    var currentItems = loadCartItems()
    if !currentItems.contains(where: { $0.id == cartItem.id }) {
        currentItems.append(cartItem)
        if let encoded = try? JSONEncoder().encode(currentItems) {
            UserDefaults.standard.set(encoded, forKey: "cartItems")
        }
    }
}

func loadCartItems() -> [CartItem] {
    if let data = UserDefaults.standard.data(forKey: "cartItems"),
       let decoded = try? JSONDecoder().decode([CartItem].self, from: data) {
        return decoded
    }
    return []
}




