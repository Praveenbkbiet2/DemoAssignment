//
//  MainTabView.swift
//  GifSwiftUI
//
//  Created by Praveen Verma on 16/04/25.
//

import Foundation
import SwiftUI


struct MainTabView: View {
    
    let product: Product
    
    var body: some View {
        TabView {
            NavigationStack {
                HomeView()
            }
            .tabItem {
                Image(systemName: "house.fill")
                Text("Home")
            }

            Text("Catalog")
                .tabItem {
                    Image(systemName: "square.grid.2x2")
                    Text("Catalog")
                }

            
            CartView()
                .tabItem {
                    Image(systemName: "cart")
                    Text("Cart")
                }

            Text("Favorites")
                .tabItem {
                    Image(systemName: "heart")
                    Text("Favorites")
                }

            Text("Profile")
                .tabItem {
                    Image(systemName: "person")
                    Text("Profile")
                }
        }
    }
}

func shareProduct () {
    let text = "I'm using this app! An awesome app."
    guard let urlShare = URL(string: "https://apps.apple.com/") else { return }
    let activityVC = UIActivityViewController(activityItems: [text, urlShare], applicationActivities: nil)

    if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
       let window = scene.windows.first,
       let rootVC = window.rootViewController {
        rootVC.present(activityVC, animated: true, completion: nil)
    }
}
